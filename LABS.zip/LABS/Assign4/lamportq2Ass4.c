#include <stdio.h>
#include <stdlib.h>

// Global logical clock
int lamport_clock = 0;

// Function to simulate sending a request to enter the critical section
void send_request(int process_id) {
    lamport_clock++;  // Increment logical clock for each event
    printf("Process %d sends request at time %d\n", process_id, lamport_clock);
}

// Function to simulate receiving a request from another process
void receive_request(int process_id, int sender_id, int sender_time) {
    lamport_clock = (sender_time > lamport_clock) ? sender_time + 1 : lamport_clock + 1;  // Synchronize clocks
    printf("Process %d receives request from Process %d at time %d\n", process_id, sender_id, lamport_clock);
}

// Function to simulate entering the critical section
void enter_critical_section(int process_id) {
    printf("Process %d entering critical section at time %d\n", process_id, lamport_clock);
}

// Function to simulate exiting the critical section
void exit_critical_section(int process_id) {
    printf("Process %d exiting critical section at time %d\n", process_id, lamport_clock);
}

int main() {
    // Simulating mutual exclusion between two processes
    int process_1 = 1;
    int process_2 = 2;

    // Simulate process 1 requesting to enter the critical section
    send_request(process_1);  // Process 1 sends request
    receive_request(process_2, process_1, lamport_clock);  // Process 2 receives request from process 1

    enter_critical_section(process_1);  // Process 1 enters the critical section
    exit_critical_section(process_1);  // Process 1 exits the critical section

    // Simulate process 2 requesting to enter the critical section
    send_request(process_2);  // Process 2 sends request
    receive_request(process_1, process_2, lamport_clock);  // Process 1 receives request from process 2

    enter_critical_section(process_2);  // Process 2 enters the critical section
    exit_critical_section(process_2);  // Process 2 exits the critical section

    return 0;
}
