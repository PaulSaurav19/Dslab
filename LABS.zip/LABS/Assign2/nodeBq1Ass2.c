#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>

#define PORT 8080
#define BUFFER_SIZE 256

// Function to get the CPU load on Linux using /proc/stat
void get_cpu_load(char *buffer, size_t size) {
    FILE *fp;
    long unsigned int user, nice, system, idle, total1, total2;
    static long unsigned int prev_total = 0, prev_idle = 0;

    // Open /proc/stat to read CPU statistics
    fp = fopen("/proc/stat", "r");
    if (fp == NULL) {
        snprintf(buffer, size, "Error retrieving CPU load");
        return;
    }

    // Read the CPU times from the first line (which starts with "cpu")
    if (fscanf(fp, "cpu  %lu %lu %lu %lu", &user, &nice, &system, &idle) != 4) {
        snprintf(buffer, size, "Error reading CPU load");
        fclose(fp);
        return;
    }
    fclose(fp);

    total1 = user + nice + system + idle;
    // Calculate the change in CPU load
    total2 = total1 - prev_total;
    idle = idle - prev_idle;

    // Calculate the CPU usage as (1 - idle/total) * 100
    float cpu_usage = (1.0f - (float)idle / total2) * 100;

    // Save the current values for next calculation
    prev_total = total1;
    prev_idle = idle;

    // Format and return the CPU load as a string
    snprintf(buffer, size, "CPU Load: %.2f%%", cpu_usage);
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};

    // Create the socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Set the server address
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind the socket to the port
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d...\n", PORT);

    // Accept incoming connection
    if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
        perror("accept failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Get the CPU load from the system
    get_cpu_load(buffer, sizeof(buffer));

    // Send the CPU load information to the client
    if (send(new_socket, buffer, strlen(buffer), 0) < 0) {
        perror("send failed");
        close(new_socket);
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Close the sockets
    close(new_socket);
    close(server_fd);

    return 0;
}
