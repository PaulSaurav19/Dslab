#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <semaphore.h>

#define SHARED_MEM_NAME "/shared_mem"
#define SEMAPHORE_NAME "/sem_example"
#define SHARED_MEM_SIZE sizeof(int)

int main() {
    int fd;
    int *shared_counter;
    sem_t *sem;

    // Open the shared memory object
    fd = shm_open(SHARED_MEM_NAME, O_RDWR, 0666);  // Open without O_CREAT (client only reads)
    if (fd == -1) {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }

    // Map the shared memory object into memory
    shared_counter = mmap(NULL, SHARED_MEM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (shared_counter == MAP_FAILED) {
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    // Open the semaphore (already created by the server)
    sem = sem_open(SEMAPHORE_NAME, 0);  // 0 means the client just opens it without creating
    if (sem == SEM_FAILED) {
        perror("sem_open");
        exit(EXIT_FAILURE);
    }

    // Loop to read the counter value in shared memory
    while (1) {
        sem_wait(sem);  // Wait on the semaphore to enter critical section

        printf("Counter value: %d\n", *shared_counter);  // Print the counter value

        sem_post(sem);  // Release the semaphore after critical section
        sleep(1);  // Sleep for 1 second
    }

    // Clean up resources
    munmap(shared_counter, SHARED_MEM_SIZE);
    close(fd);
    sem_close(sem);

    return 0;
}
