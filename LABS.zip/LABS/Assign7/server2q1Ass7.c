#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctype.h>

#define PORT 12346
#define BUFFER_SIZE 1024

float get_cpu_load() {
    // Simulate CPU load between 0 and 1
    return (rand() % 100) / 100.0;
}

void to_uppercase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = toupper(str[i]);
    }
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFFER_SIZE];
    socklen_t addr_len;

    // Create a socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Set up server address structure
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the address and port
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Start listening for connections
    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server2 listening on port %d...\n", PORT);

    while (1) {
        addr_len = sizeof(client_addr);
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        printf("Accepted connection from load balancer...\n");

        // Receive data from the load balancer
        memset(buffer, 0, BUFFER_SIZE); // Clear buffer
        recv(client_socket, buffer, BUFFER_SIZE, 0);

        if (strcmp(buffer, "CPU") == 0) {
            // Respond with CPU load
            float cpu_load = get_cpu_load();
            send(client_socket, &cpu_load, sizeof(cpu_load), 0);
            printf("Sent CPU load: %.2f\n", cpu_load);
        } else {
            // Convert string to uppercase
            to_uppercase(buffer);
            send(client_socket, buffer, strlen(buffer), 0);
            printf("Sent uppercase string: %s\n", buffer);
        }

        // Close the client socket
        close(client_socket);
    }

    // Close the server socket
    close(server_socket);
    return 0;
}
