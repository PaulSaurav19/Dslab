#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BROKER_PORT 12347
#define BUFFER_SIZE 1024

int main() {
    int sock;
    struct sockaddr_in broker_addr;
    char buffer[BUFFER_SIZE], result[BUFFER_SIZE];

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Set up the broker address
    broker_addr.sin_family = AF_INET;
    broker_addr.sin_port = htons(BROKER_PORT);
    broker_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to the broker server
    if (connect(sock, (struct sockaddr *)&broker_addr, sizeof(broker_addr)) < 0) {
        perror("Connection failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Get the input string from the user
    printf("Enter a string to convert: ");
    fgets(buffer, BUFFER_SIZE, stdin);

    // Remove the newline character from the string
    buffer[strlen(buffer) - 1] = '\0';

    // Send the string to the broker server
    send(sock, buffer, strlen(buffer), 0);

    // Receive the result from the server
    memset(result, 0, sizeof(result)); // Clear the result buffer
    int bytes_received = recv(sock, result, BUFFER_SIZE, 0);
    if (bytes_received < 0) {
        perror("Error receiving data");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Null-terminate the received result string
    result[bytes_received] = '\0';

    // Display the result
    printf("Received uppercase string: %s\n", result);

    // Close the socket
    close(sock);

    return 0;
}
