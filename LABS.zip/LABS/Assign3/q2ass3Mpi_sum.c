#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

/*sudo apt update
sudo apt install openmpi-bin openmpi-common libopenmpi-dev
*/

#define ARRAY_SIZE 10  // Total number of elements in the array

int main(int argc, char** argv) {
    int world_rank, world_size;
    double *array = NULL;  // Array only on the root process
    double *sub_array;     // Sub-array for each process
    int elements_per_proc; // Number of elements per process
    double local_sum = 0.0, total_sum = 0.0;

    // Initialize the MPI environment
    MPI_Init(&argc, &argv);

    // Get the rank of the process and the total number of processes
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    // Determine the number of elements per process
    elements_per_proc = ARRAY_SIZE / world_size;

    // Allocate memory for the sub-array
    sub_array = (double*)malloc(elements_per_proc * sizeof(double));

    // Initialize the array on the root process
    if (world_rank == 0) {
        array = (double*)malloc(ARRAY_SIZE * sizeof(double));
        for (int i = 0; i < ARRAY_SIZE; i++) {
            array[i] = i + 1;  // Example: Fill array with 1.0
        }
    }

    // Scatter chunks of the array to all processes
    MPI_Scatter(array, elements_per_proc, MPI_DOUBLE, sub_array, elements_per_proc, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    // Each process calculates the sum of its chunk
    for (int i = 0; i < elements_per_proc; i++) {
        local_sum += sub_array[i];
    }

    // Reduce all local sums into a total sum at the root process
    MPI_Reduce(&local_sum, &total_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    // The root process prints the total sum
    if (world_rank == 0) {
        printf("Total sum of array elements is: %f\n", total_sum);
        free(array);  // Free the allocated memory on the root process
    }

    // Free allocated memory for sub-arrays
    free(sub_array);

    // Finalize the MPI environment
    MPI_Finalize();

    return 0;
}
