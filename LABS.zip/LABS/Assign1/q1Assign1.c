/* Write a program to create two processes. First process takes a string and passes 
it to second process through a pipe. The second process concatenates the received 
string with another string without using string function and sends it back to the first 
process for printing. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#define MAX_LEN 256                   // Maximum length for each line of input
#define MAX_BUFFER_SIZE 1024          // Maximum total buffer size for multi-line input
#define ADDITIONAL_STRING " - Modified by child"  // String to be appended by the child process

// Function to concatenate strings without using strcat
void concatenate_without_strcat(char *dest, const char *src) {
    while (*dest != '\0') {           // Move to the end of the destination string
        dest++;
    }
    while (*src != '\0') {            // Append characters from the source string to the destination
        *dest++ = *src++;
    }
    *dest = '\0';                     // Null-terminate the resulting string
}

int main() {
    int pipe1[2], pipe2[2];           // Two pipes for bidirectional communication
    pid_t pid;
    char input_line[MAX_LEN];         // Buffer for a single line of user input
    char input_buffer[MAX_BUFFER_SIZE] = "";  // Accumulator for multi-line input
    char result_buffer[MAX_BUFFER_SIZE];      // Buffer for modified string

    // Create pipes
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Fork the process
    if ((pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {                   // Child process
        close(pipe1[1]);              // Close unused write end of pipe1
        close(pipe2[0]);              // Close unused read end of pipe2

        // Read multi-line input from the parent through pipe1
        read(pipe1[0], result_buffer, MAX_BUFFER_SIZE);
        close(pipe1[0]);              // Close read end of pipe1 after reading

        // Append the additional string to the input
        concatenate_without_strcat(result_buffer, ADDITIONAL_STRING);

        // Send the modified string back to the parent through pipe2
        write(pipe2[1], result_buffer, strlen(result_buffer) + 1);
        close(pipe2[1]);              // Close write end of pipe2 after writing

        exit(EXIT_SUCCESS);           // Exit the child process
    } else {                          // Parent process
        close(pipe1[0]);              // Close unused read end of pipe1
        close(pipe2[1]);              // Close unused write end of pipe2

        printf("Enter multi-line input (enter a blank line to finish):\n");

        // Read multiple lines of input until a blank line is entered
        while (1) {
            fgets(input_line, MAX_LEN, stdin);
            if (strcmp(input_line, "\n") == 0) {  // Stop on a blank line
                break;
            }
            strcat(input_buffer, input_line);    // Accumulate input lines
        }

        // Write the multi-line input to the child through pipe1
        write(pipe1[1], input_buffer, strlen(input_buffer) + 1);
        close(pipe1[1]);              // Close write end of pipe1 after writing

        // Wait for the child process to complete
        wait(NULL);

        // Read the modified string from the child through pipe2
        read(pipe2[0], result_buffer, MAX_BUFFER_SIZE);
        close(pipe2[0]);              // Close read end of pipe2 after reading

        // Print the modified string received from the child
        printf("Modified string from child:\n%s", result_buffer);
    }

    return 0;                         // Return success
}
